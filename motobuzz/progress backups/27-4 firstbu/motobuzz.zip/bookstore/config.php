<?php

$conn = mysqli_connect('localhost','root','','bikeacc') or die('connection failed');

?>